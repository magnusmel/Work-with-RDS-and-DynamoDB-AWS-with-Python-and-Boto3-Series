# manage_dynamodb
Managing DynamoDB with Python and Boto3
